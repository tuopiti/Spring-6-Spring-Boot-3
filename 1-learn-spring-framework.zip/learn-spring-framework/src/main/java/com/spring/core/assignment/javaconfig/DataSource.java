package com.spring.core.assignment.javaconfig;

public interface DataSource {
    String[] getEmails();
}
