package com.spring.core.assignment;

public interface DataSource {
    String[] getEmails();
}
