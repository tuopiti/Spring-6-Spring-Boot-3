package com.spring.core.di;

public interface MessageService {
    void sendMessage(String message);
}
