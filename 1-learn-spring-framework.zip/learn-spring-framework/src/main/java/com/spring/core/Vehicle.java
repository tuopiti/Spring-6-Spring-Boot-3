package com.spring.core;

public interface Vehicle {

    void move();
}
