package net.javaguides.springannotations.config;

import net.javaguides.springannotations.lazy.EagerLoader;
import net.javaguides.springannotations.lazy.LazyLoader;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

@Configuration
//@Lazy
public class AppConfig {

//    @Bean
//    @Lazy
//    public LazyLoader lazyLoader(){
//        return new LazyLoader();
//    }
//
//    @Bean
//    public EagerLoader eagerLoader(){
//        return new EagerLoader();
//    }
}
