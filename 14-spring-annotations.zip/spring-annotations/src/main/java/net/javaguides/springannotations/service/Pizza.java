package net.javaguides.springannotations.service;

public interface Pizza {

    String getPizza();
}
